package 自增运算符;

/**
 * @Author: sophia
 * @Description: 反编译
 * @Date: 2020/7/3 10:19
 * @Version :1.0
 */
public class Test2 {
    public static void main(String[] args) {
        int a = 1;
        a = a++;
        System.out.println(a);
    }
}
