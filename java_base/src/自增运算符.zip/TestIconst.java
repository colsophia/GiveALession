package 自增运算符;

/**
 * @Author: sophia
 * @Description:
 * @Date: 2020/7/3 10:32
 * @Version :1.0
 */
public class TestIconst {
    public static void main(String[] args) {
        int a = -1;
        int b = 3;
    }
}
/**
 *     Code:
 *        0: iconst_m1
 *        1: istore_1
 *        2: iconst_3
 *        3: istore_2
 *        4: return
 */
