package 自增运算符;

/**
 * @Author: sophia
 * @Description:
 * @Date: 2020/7/3 10:39
 * @Version :1.0
 */
public class Testsipush {
    public static void main(String[] args) {
        int a = 129;
        int b = -200;
    }
}
/**
 *     Code:
 *        0: sipush        129
 *        3: istore_1
 *        4: sipush        -200
 *        7: istore_2
 *        8: return
 */
